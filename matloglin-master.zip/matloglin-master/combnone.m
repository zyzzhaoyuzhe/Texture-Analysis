function ops = combnone(type, n) %#ok<INUSD>

ops = [];