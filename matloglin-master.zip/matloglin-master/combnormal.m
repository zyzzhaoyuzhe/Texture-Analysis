function ops = combnormal(type, n)

ops = struct('type', type, 'args', struct('n', n, 'scale', 1/n));