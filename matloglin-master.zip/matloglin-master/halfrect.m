function r = rect(x)

r = (x >= 0).*x;