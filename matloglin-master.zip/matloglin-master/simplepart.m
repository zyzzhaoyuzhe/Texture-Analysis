function r = simplepart(x)

r = (x == 0)*0.5 + (x > 0);