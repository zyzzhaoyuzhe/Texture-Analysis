function deg = rad2deg(rad)

deg = rad/pi*180;
